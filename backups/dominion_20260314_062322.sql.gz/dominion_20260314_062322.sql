--
-- PostgreSQL database dump
--

\restrict Pa2siZTsFGzkt7uDYgFgTqgxtlcVuvkGbhM1EShQUYQrnAKjwqCSCuSJjsb80gv

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: briefingtype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.briefingtype AS ENUM (
    'INTRODUCTORY',
    'PRE_TRIP',
    'SEASONAL',
    'SPECIAL',
    'UNSCHEDULED'
);


--
-- Name: medicalchecktype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.medicalchecktype AS ENUM (
    'PRE_TRIP',
    'POST_TRIP',
    'PERIODIC',
    'EXTRAORDINARY'
);


--
-- Name: ownershiptype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.ownershiptype AS ENUM (
    'SUBLEASE',
    'CONNECTED',
    'OWNED_5T',
    'PARTNER_GAZELLE'
);


--
-- Name: technicalchecktype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.technicalchecktype AS ENUM (
    'PRE_TRIP',
    'POST_TRIP',
    'MAINTENANCE',
    'DEFECT'
);


--
-- Name: tripstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tripstatus AS ENUM (
    'DRAFT',
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'master',
    'director',
    'admin',
    'convoy_head',
    'manager'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: briefings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.briefings (
    id integer NOT NULL,
    driver_id integer NOT NULL,
    instructor_id integer NOT NULL,
    briefing_type public.briefingtype NOT NULL,
    topic character varying(500) NOT NULL,
    is_passed boolean
);


--
-- Name: briefings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.briefings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: briefings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.briefings_id_seq OWNED BY public.briefings.id;


--
-- Name: call_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.call_logs (
    id integer NOT NULL,
    tenant_id character varying(100) NOT NULL,
    user_id integer,
    caller_phone character varying(20),
    callee_phone character varying(20),
    call_status character varying(20),
    duration integer,
    recording_url text,
    ai_rating integer,
    "timestamp" timestamp without time zone,
    asterisk_unique_id character varying(64)
);


--
-- Name: call_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.call_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: call_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.call_logs_id_seq OWNED BY public.call_logs.id;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    role character varying,
    content text,
    group_name character varying,
    thread_id character varying,
    parent_id integer,
    user_id integer,
    attachments jsonb,
    file_path character varying,
    is_read boolean,
    "timestamp" timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- Name: contract_term_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_term_history (
    id integer NOT NULL,
    contract_term_id integer NOT NULL,
    vehicle_id integer,
    changed_by_user_id integer,
    changed_by character varying(100),
    changes jsonb,
    note text,
    changed_at timestamp without time zone
);


--
-- Name: contract_term_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_term_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_term_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_term_history_id_seq OWNED BY public.contract_term_history.id;


--
-- Name: contract_terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_terms (
    id integer NOT NULL,
    vehicle_id integer,
    driver_id integer,
    park_name character varying,
    is_default boolean,
    partner_daily_rent double precision,
    driver_daily_rent double precision,
    commission_rate double precision,
    day_off_rate double precision,
    is_repair boolean,
    is_day_off boolean,
    is_idle boolean,
    meta jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: contract_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_terms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_terms_id_seq OWNED BY public.contract_terms.id;


--
-- Name: driver_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.driver_profiles (
    id integer NOT NULL,
    user_id integer,
    license_number character varying,
    license_expiry date,
    medical_expiry date,
    total_trips integer,
    total_earnings double precision,
    online_time_seconds integer,
    tension_index double precision,
    yandex_driver_id character varying,
    yandex_balance double precision,
    yandex_rating double precision,
    yandex_work_status character varying(50),
    yandex_last_sync_at timestamp without time zone,
    last_notification timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: driver_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.driver_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: driver_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.driver_profiles_id_seq OWNED BY public.driver_profiles.id;


--
-- Name: driver_tension_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.driver_tension_history (
    id integer NOT NULL,
    driver_id integer,
    tension_index double precision NOT NULL,
    calculated_at timestamp without time zone
);


--
-- Name: driver_tension_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.driver_tension_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: driver_tension_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.driver_tension_history_id_seq OWNED BY public.driver_tension_history.id;


--
-- Name: financial_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_log (
    id integer NOT NULL,
    vehicle_id integer,
    driver_id integer,
    park_name character varying,
    entry_type character varying,
    amount double precision,
    note text,
    meta jsonb,
    created_at timestamp without time zone
);


--
-- Name: financial_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.financial_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: financial_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.financial_log_id_seq OWNED BY public.financial_log.id;


--
-- Name: fine_installments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fine_installments (
    id integer NOT NULL,
    driver_id integer,
    total_debt_amount numeric(12,2) NOT NULL,
    remaining_debt numeric(12,2) NOT NULL,
    daily_deduction_default numeric(12,2) NOT NULL,
    status character varying,
    is_frozen boolean,
    freeze_reason text,
    created_at timestamp without time zone
);


--
-- Name: fine_installments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fine_installments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fine_installments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fine_installments_id_seq OWNED BY public.fine_installments.id;


--
-- Name: logistics_drivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logistics_drivers (
    id integer NOT NULL,
    park_name character varying,
    tenant_id character varying,
    name character varying NOT NULL,
    short_name character varying NOT NULL,
    group_name character varying NOT NULL,
    vehicle_name character varying,
    vehicle_type character varying,
    payment_type character varying,
    rate_per_point numeric(10,2),
    is_active boolean,
    phone character varying,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: logistics_drivers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.logistics_drivers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logistics_drivers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.logistics_drivers_id_seq OWNED BY public.logistics_drivers.id;


--
-- Name: logistics_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logistics_routes (
    id integer NOT NULL,
    park_name character varying,
    tenant_id character varying,
    date date NOT NULL,
    route_code character varying NOT NULL,
    route_type character varying NOT NULL,
    driver_name character varying NOT NULL,
    driver_group character varying NOT NULL,
    vehicle_name character varying,
    revenue numeric(12,2) NOT NULL,
    driver_payment numeric(12,2) NOT NULL,
    fuel_cost numeric(12,2),
    maintenance_cost numeric(12,2),
    margin numeric(12,2),
    sglobal_share numeric(12,2),
    mkrtchan_share numeric(12,2),
    delivery_points integer,
    status character varying,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: logistics_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.logistics_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logistics_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.logistics_routes_id_seq OWNED BY public.logistics_routes.id;


--
-- Name: medical_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medical_checks (
    id integer NOT NULL,
    driver_id integer NOT NULL,
    medical_staff_id integer,
    check_type public.medicalchecktype NOT NULL,
    check_time timestamp without time zone,
    blood_pressure character varying(20),
    alcohol_test boolean,
    is_fit boolean NOT NULL
);


--
-- Name: medical_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.medical_checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: medical_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.medical_checks_id_seq OWNED BY public.medical_checks.id;


--
-- Name: oracle_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oracle_archive (
    id integer NOT NULL,
    title character varying,
    channel character varying,
    content text,
    severity character varying,
    meta jsonb,
    created_at timestamp without time zone
);


--
-- Name: oracle_archive_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oracle_archive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oracle_archive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oracle_archive_id_seq OWNED BY public.oracle_archive.id;


--
-- Name: partner_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partner_ledger (
    id integer NOT NULL,
    partner_id integer,
    vehicle_id integer,
    incoming double precision,
    outgoing double precision,
    expense_type character varying,
    expense_description text,
    vehicle_status character varying,
    daily_rate_applied double precision,
    date date,
    created_at timestamp without time zone
);


--
-- Name: partner_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.partner_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: partner_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.partner_ledger_id_seq OWNED BY public.partner_ledger.id;


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id integer NOT NULL,
    name character varying NOT NULL,
    phone character varying,
    telegram_id character varying,
    login_code character varying,
    last_login timestamp without time zone,
    created_at timestamp without time zone,
    is_active boolean
);


--
-- Name: partners_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.partners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: partners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.partners_id_seq OWNED BY public.partners.id;


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referrals (
    id integer NOT NULL,
    referrer_id integer,
    referral_id integer,
    status character varying,
    reward_amount double precision,
    required_trips integer,
    current_trips integer,
    created_at timestamp without time zone,
    paid_at timestamp without time zone
);


--
-- Name: referrals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.referrals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: referrals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.referrals_id_seq OWNED BY public.referrals.id;


--
-- Name: rental_tariffs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rental_tariffs (
    id integer NOT NULL,
    name character varying NOT NULL,
    car_class character varying NOT NULL,
    rent_to_driver double precision NOT NULL,
    base_cost_to_partner double precision NOT NULL,
    description character varying,
    created_at timestamp without time zone
);


--
-- Name: rental_tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rental_tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rental_tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rental_tariffs_id_seq OWNED BY public.rental_tariffs.id;


--
-- Name: service_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_orders (
    id integer NOT NULL,
    order_number character varying NOT NULL,
    vehicle_id integer NOT NULL,
    mechanic_id integer,
    description text,
    parts_json jsonb,
    labor_cost double precision,
    parts_cost double precision,
    total_cost double precision,
    status character varying,
    mileage_in integer,
    mileage_out integer,
    created_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    notes text,
    pdf_path character varying
);


--
-- Name: service_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_orders_id_seq OWNED BY public.service_orders.id;


--
-- Name: staff_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_reports (
    id integer NOT NULL,
    user_id integer,
    stars integer,
    date date
);


--
-- Name: staff_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_reports_id_seq OWNED BY public.staff_reports.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying NOT NULL,
    contact_person character varying,
    phone character varying,
    email character varying,
    address text,
    inn character varying,
    delivery_days integer,
    min_order_amount double precision,
    rating double precision,
    is_active boolean,
    created_at timestamp without time zone,
    notes text
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: technical_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technical_checks (
    id integer NOT NULL,
    vehicle_id integer NOT NULL,
    mechanic_id integer NOT NULL,
    check_type public.technicalchecktype NOT NULL,
    check_time timestamp without time zone,
    is_passed boolean NOT NULL
);


--
-- Name: technical_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.technical_checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: technical_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.technical_checks_id_seq OWNED BY public.technical_checks.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    tenant_id character varying,
    park_name character varying,
    yandex_tx_id character varying,
    yandex_driver_id character varying,
    category_type character varying,
    created_at timestamp without time zone,
    category character varying,
    contractor character varying,
    description character varying,
    plate_info character varying,
    amount double precision,
    tx_type character varying,
    date timestamp without time zone,
    responsibility character varying,
    is_debt_repayment boolean
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: trip_sheets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trip_sheets (
    id integer NOT NULL,
    trip_number character varying(50) NOT NULL,
    driver_id integer NOT NULL,
    vehicle_id integer NOT NULL,
    start_time timestamp without time zone NOT NULL,
    actual_end_time timestamp without time zone,
    start_location character varying(500) NOT NULL,
    start_odometer integer NOT NULL,
    medical_check_id integer,
    technical_check_id integer,
    briefing_id integer,
    kis_art_required boolean,
    kis_art_sent boolean,
    kis_art_response jsonb,
    status public.tripstatus NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: trip_sheets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trip_sheets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trip_sheets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trip_sheets_id_seq OWNED BY public.trip_sheets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    tenant_id character varying,
    username character varying,
    hashed_password character varying,
    full_name character varying,
    photo_url character varying,
    telegram_id character varying,
    phone character varying,
    role public.user_role DEFAULT 'manager'::public.user_role,
    rating double precision,
    park_name character varying,
    can_see_treasury boolean,
    can_see_fleet boolean,
    can_see_analytics boolean,
    can_see_logistics boolean,
    can_see_hr boolean,
    can_edit_users boolean,
    language character varying,
    theme character varying,
    is_active boolean,
    created_at timestamp without time zone,
    last_active_at timestamp without time zone,
    is_archived boolean,
    is_core_active boolean,
    base_salary double precision,
    kpi_bonus_ratio double precision,
    m4_fines_count integer,
    realtime_status character varying,
    work_status character varying,
    yandex_driver_id character varying,
    yandex_contractor_id character varying,
    driver_class character varying,
    daily_rent double precision,
    base_cost double precision,
    driver_balance double precision,
    current_vehicle_id integer,
    yandex_work_status character varying(50),
    yandex_balance_updated_at timestamp without time zone,
    yandex_rating double precision,
    yandex_phones jsonb,
    yandex_names jsonb,
    yandex_current_car jsonb,
    yandex_last_sync_at timestamp without time zone,
    license_number character varying(30),
    license_issue_date date,
    license_expiry_date date,
    license_country character varying(10),
    driving_experience_from date,
    birth_date date,
    hire_date date,
    first_order_date date,
    balance_limit double precision,
    driver_documents jsonb
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicle_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_profiles (
    id integer NOT NULL,
    vehicle_id integer,
    osago_number character varying,
    osago_expiry date,
    kasko_number character varying,
    kasko_expiry date,
    license_expiry date,
    diagnostic_card_expiry date,
    last_to_date date,
    next_to_date date,
    to_interval_km integer,
    trip_sheets_count integer,
    acceptance_acts_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: vehicle_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_profiles_id_seq OWNED BY public.vehicle_profiles.id;


--
-- Name: vehicle_repair_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_repair_history (
    id integer NOT NULL,
    vehicle_id integer,
    parts_json jsonb,
    description text NOT NULL,
    repair_cost double precision,
    status character varying,
    created_at timestamp without time zone
);


--
-- Name: vehicle_repair_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_repair_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_repair_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_repair_history_id_seq OWNED BY public.vehicle_repair_history.id;


--
-- Name: vehicle_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_status_history (
    id integer NOT NULL,
    vehicle_id integer NOT NULL,
    old_status character varying(50),
    new_status character varying(50) NOT NULL,
    changed_by character varying(100),
    changed_at timestamp without time zone,
    reason text
);


--
-- Name: vehicle_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_status_history_id_seq OWNED BY public.vehicle_status_history.id;


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicles (
    id integer NOT NULL,
    tenant_id character varying,
    brand character varying,
    model character varying,
    license_plate character varying,
    vin character varying,
    color character varying,
    year integer,
    sts_number character varying,
    callsign character varying,
    owner_id integer,
    ownership_type public.ownershiptype,
    commission_rate double precision,
    fixed_fee double precision,
    park_name character varying,
    is_park_car boolean,
    tariff_id integer,
    is_active boolean,
    is_free boolean,
    status character varying,
    current_driver_id integer,
    current_mileage double precision,
    next_service_km double precision,
    yandex_car_id character varying,
    yandex_driver_id character varying,
    last_update timestamp without time zone,
    created_at timestamp without time zone,
    is_active_dominion boolean,
    last_transaction_at timestamp without time zone,
    yandex_status character varying(50),
    yandex_rental boolean,
    yandex_last_sync_at timestamp without time zone,
    yandex_park_id character varying(100)
);


--
-- Name: vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicles_id_seq OWNED BY public.vehicles.id;


--
-- Name: warehouse_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouse_items (
    id integer NOT NULL,
    name character varying NOT NULL,
    sku character varying,
    category character varying,
    quantity integer,
    min_threshold integer,
    price_unit double precision,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: warehouse_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouse_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouse_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouse_items_id_seq OWNED BY public.warehouse_items.id;


--
-- Name: warehouse_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouse_logs (
    id integer NOT NULL,
    item_id integer,
    change integer,
    vehicle_id integer,
    master_id integer,
    "timestamp" timestamp without time zone DEFAULT now()
);


--
-- Name: warehouse_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouse_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouse_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouse_logs_id_seq OWNED BY public.warehouse_logs.id;


--
-- Name: yandex_sync_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.yandex_sync_log (
    id integer NOT NULL,
    sync_type character varying(50) NOT NULL,
    park_id character varying(100) NOT NULL,
    records_processed integer,
    records_created integer,
    records_updated integer,
    errors_count integer,
    error_details jsonb,
    started_at timestamp without time zone NOT NULL,
    finished_at timestamp without time zone,
    duration_seconds double precision
);


--
-- Name: yandex_sync_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.yandex_sync_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: yandex_sync_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.yandex_sync_log_id_seq OWNED BY public.yandex_sync_log.id;


--
-- Name: briefings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefings ALTER COLUMN id SET DEFAULT nextval('public.briefings_id_seq'::regclass);


--
-- Name: call_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_logs ALTER COLUMN id SET DEFAULT nextval('public.call_logs_id_seq'::regclass);


--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- Name: contract_term_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_term_history ALTER COLUMN id SET DEFAULT nextval('public.contract_term_history_id_seq'::regclass);


--
-- Name: contract_terms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_terms ALTER COLUMN id SET DEFAULT nextval('public.contract_terms_id_seq'::regclass);


--
-- Name: driver_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.driver_profiles ALTER COLUMN id SET DEFAULT nextval('public.driver_profiles_id_seq'::regclass);


--
-- Name: driver_tension_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.driver_tension_history ALTER COLUMN id SET DEFAULT nextval('public.driver_tension_history_id_seq'::regclass);


--
-- Name: financial_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_log ALTER COLUMN id SET DEFAULT nextval('public.financial_log_id_seq'::regclass);


--
-- Name: fine_installments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fine_installments ALTER COLUMN id SET DEFAULT nextval('public.fine_installments_id_seq'::regclass);


--
-- Name: logistics_drivers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_drivers ALTER COLUMN id SET DEFAULT nextval('public.logistics_drivers_id_seq'::regclass);


--
-- Name: logistics_routes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_routes ALTER COLUMN id SET DEFAULT nextval('public.logistics_routes_id_seq'::regclass);


--
-- Name: medical_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_checks ALTER COLUMN id SET DEFAULT nextval('public.medical_checks_id_seq'::regclass);


--
-- Name: oracle_archive id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oracle_archive ALTER COLUMN id SET DEFAULT nextval('public.oracle_archive_id_seq'::regclass);


--
-- Name: partner_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_ledger ALTER COLUMN id SET DEFAULT nextval('public.partner_ledger_id_seq'::regclass);


--
-- Name: partners id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners ALTER COLUMN id SET DEFAULT nextval('public.partners_id_seq'::regclass);


--
-- Name: referrals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals ALTER COLUMN id SET DEFAULT nextval('public.referrals_id_seq'::regclass);


--
-- Name: rental_tariffs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rental_tariffs ALTER COLUMN id SET DEFAULT nextval('public.rental_tariffs_id_seq'::regclass);


--
-- Name: service_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders ALTER COLUMN id SET DEFAULT nextval('public.service_orders_id_seq'::regclass);


--
-- Name: staff_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_reports ALTER COLUMN id SET DEFAULT nextval('public.staff_reports_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: technical_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_checks ALTER COLUMN id SET DEFAULT nextval('public.technical_checks_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: trip_sheets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_sheets ALTER COLUMN id SET DEFAULT nextval('public.trip_sheets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehicle_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_profiles ALTER COLUMN id SET DEFAULT nextval('public.vehicle_profiles_id_seq'::regclass);


--
-- Name: vehicle_repair_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_repair_history ALTER COLUMN id SET DEFAULT nextval('public.vehicle_repair_history_id_seq'::regclass);


--
-- Name: vehicle_status_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_status_history ALTER COLUMN id SET DEFAULT nextval('public.vehicle_status_history_id_seq'::regclass);


--
-- Name: vehicles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles ALTER COLUMN id SET DEFAULT nextval('public.vehicles_id_seq'::regclass);


--
-- Name: warehouse_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_items ALTER COLUMN id SET DEFAULT nextval('public.warehouse_items_id_seq'::regclass);


--
-- Name: warehouse_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_logs ALTER COLUMN id SET DEFAULT nextval('public.warehouse_logs_id_seq'::regclass);


--
-- Name: yandex_sync_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yandex_sync_log ALTER COLUMN id SET DEFAULT nextval('public.yandex_sync_log_id_seq'::regclass);


--
-- Data for Name: briefings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.briefings (id, driver_id, instructor_id, briefing_type, topic, is_passed) FROM stdin;
\.


--
-- Data for Name: call_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.call_logs (id, tenant_id, user_id, caller_phone, callee_phone, call_status, duration, recording_url, ai_rating, "timestamp", asterisk_unique_id) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, role, content, group_name, thread_id, parent_id, user_id, attachments, file_path, is_read, "timestamp", created_at) FROM stdin;
1	user	привет я мастер	ОБЩАЯ	\N	\N	1	[]	\N	f	2026-03-14 00:53:32.990446	2026-03-14 00:53:32.990455
2	assistant	[ДЕМО] Принял ваш запрос: 'привет я мастер'. Oracle работает в демо-режиме. Для полной активации добавьте GEMINI_API_KEY в .env	ОБЩАЯ	\N	1	\N	[]	\N	f	2026-03-14 00:53:33.093581	2026-03-14 00:53:33.093584
\.


--
-- Data for Name: contract_term_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_term_history (id, contract_term_id, vehicle_id, changed_by_user_id, changed_by, changes, note, changed_at) FROM stdin;
\.


--
-- Data for Name: contract_terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_terms (id, vehicle_id, driver_id, park_name, is_default, partner_daily_rent, driver_daily_rent, commission_rate, day_off_rate, is_repair, is_day_off, is_idle, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.driver_profiles (id, user_id, license_number, license_expiry, medical_expiry, total_trips, total_earnings, online_time_seconds, tension_index, yandex_driver_id, yandex_balance, yandex_rating, yandex_work_status, yandex_last_sync_at, last_notification, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: driver_tension_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.driver_tension_history (id, driver_id, tension_index, calculated_at) FROM stdin;
\.


--
-- Data for Name: financial_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_log (id, vehicle_id, driver_id, park_name, entry_type, amount, note, meta, created_at) FROM stdin;
1	\N	\N	EXPRESS	logistics_seed_march_10	103000	SEED: Загрузка данных 10 марта 2025 | Рейсов: 17 | Выручка: 103000 ₽ | Расходы: 53090 ₽ | Маржа: 49910 ₽ | Доля С-ГЛОБАЛ: 24955.00 ₽ | Доля Мкртчяна: 24955.00 ₽	{"date": "2025-03-10", "routes_count": 17, "total_margin": "49910", "sglobal_share": "24955.00", "total_revenue": "103000", "mkrtchan_share": "24955.00", "total_expenses": "53090"}	2026-03-14 02:41:52.352896
\.


--
-- Data for Name: fine_installments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fine_installments (id, driver_id, total_debt_amount, remaining_debt, daily_deduction_default, status, is_frozen, freeze_reason, created_at) FROM stdin;
\.


--
-- Data for Name: logistics_drivers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logistics_drivers (id, park_name, tenant_id, name, short_name, group_name, vehicle_name, vehicle_type, payment_type, rate_per_point, is_active, phone, notes, created_at) FROM stdin;
\.


--
-- Data for Name: logistics_routes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logistics_routes (id, park_name, tenant_id, date, route_code, route_type, driver_name, driver_group, vehicle_name, revenue, driver_payment, fuel_cost, maintenance_cost, margin, sglobal_share, mkrtchan_share, delivery_points, status, notes, created_at, updated_at) FROM stdin;
1	EXPRESS	s-global	2025-03-10	8464ДС_БольшаяЧеремушкинская2	darkstore	ШАХЗОД	BNYAN	Газель	7622.00	3800.00	0.00	0.00	3822.00	1911.00	1911.00	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
2	EXPRESS	s-global	2025-03-10	9107ДС_НиколоХованская7	darkstore	ШАХЗОД	BNYAN	Газель	7622.00	3800.00	0.00	0.00	3822.00	1911.00	1911.00	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
3	EXPRESS	s-global	2025-03-10	7215ДС_Профсоюзная88	darkstore	ЗАРИФ	BNYAN	Газель	7622.00	3800.00	0.00	0.00	3822.00	1911.00	1911.00	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
4	EXPRESS	s-global	2025-03-10	6341ДС_Ленинский45	darkstore	ЗАРИФ	BNYAN	Газель	7622.00	3800.00	0.00	0.00	3822.00	1911.00	1911.00	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
5	EXPRESS	s-global	2025-03-10	5892ДС_Варшавское12	darkstore	ШАВКАТ	BNYAN	Газель	7622.00	3800.00	0.00	0.00	3822.00	1911.00	1911.00	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
6	EXPRESS	s-global	2025-03-10	7341М_Люсиновская4	store	ШАХЗОД	BNYAN	Газель	6795.00	3200.00	0.00	0.00	3595.00	1797.50	1797.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
7	EXPRESS	s-global	2025-03-10	4537М_МиклухоМаклая43	store	ШАХЗОД	BNYAN	Газель	6795.00	3200.00	0.00	0.00	3595.00	1797.50	1797.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
8	EXPRESS	s-global	2025-03-10	6736М_Стремянный2	store	ЗАРИФ	BNYAN	Газель	6795.00	3200.00	0.00	0.00	3595.00	1797.50	1797.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
9	EXPRESS	s-global	2025-03-10	3218М_Нагатинская18	store	ЗАРИФ	BNYAN	Газель	6795.00	3200.00	0.00	0.00	3595.00	1797.50	1797.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
10	EXPRESS	s-global	2025-03-10	8901М_Каширское65	store	ШАВКАТ	BNYAN	Газель	6795.00	3200.00	0.00	0.00	3595.00	1797.50	1797.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
11	EXPRESS	s-global	2025-03-10	8500Ш_Мичуринский16	shmel	ШАХЗОД	BNYAN	Газель	4483.00	2000.00	0.00	0.00	2483.00	1241.50	1241.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
12	EXPRESS	s-global	2025-03-10	6956Ш_1йГрайвороновский13	shmel	ЗАРИФ	BNYAN	Газель	4483.00	2000.00	0.00	0.00	2483.00	1241.50	1241.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
13	EXPRESS	s-global	2025-03-10	5124Ш_Коломенская3	shmel	ШАВКАТ	BNYAN	Газель	4483.00	2000.00	0.00	0.00	2483.00	1241.50	1241.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
14	EXPRESS	s-global	2025-03-10	7733Ш_Автозаводская22	shmel	ШАВКАТ	BNYAN	Газель	4483.00	2000.00	0.00	0.00	2483.00	1241.50	1241.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
15	EXPRESS	s-global	2025-03-10	7627Ж_Сколковское40	zhuk	ШАХЗОД	BNYAN	Газель	2434.00	1045.00	0.00	0.00	1389.00	694.50	694.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
16	EXPRESS	s-global	2025-03-10	8171Ж_Зворыкина14	zhuk	ШАВКАТ	BNYAN	Газель	2434.00	1045.00	0.00	0.00	1389.00	694.50	694.50	0	completed	\N	2026-03-14 02:41:52.3459+00	\N
17	EXPRESS	s-global	2025-03-10	ATEGO_МаршрутДС_10марта	darkstore	АЗАТ	AZAT	Mercedes Atego	8115.00	8000.00	0.00	0.00	115.00	57.50	57.50	4	completed	Азат: 4 точки доставки × 2000 ₽. Mercedes Atego (собственный транспорт).	2026-03-14 02:41:52.3459+00	\N
\.


--
-- Data for Name: medical_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medical_checks (id, driver_id, medical_staff_id, check_type, check_time, blood_pressure, alcohol_test, is_fit) FROM stdin;
\.


--
-- Data for Name: oracle_archive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oracle_archive (id, title, channel, content, severity, meta, created_at) FROM stdin;
\.


--
-- Data for Name: partner_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partner_ledger (id, partner_id, vehicle_id, incoming, outgoing, expense_type, expense_description, vehicle_status, daily_rate_applied, date, created_at) FROM stdin;
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partners (id, name, phone, telegram_id, login_code, last_login, created_at, is_active) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referrals (id, referrer_id, referral_id, status, reward_amount, required_trips, current_trips, created_at, paid_at) FROM stdin;
\.


--
-- Data for Name: rental_tariffs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rental_tariffs (id, name, car_class, rent_to_driver, base_cost_to_partner, description, created_at) FROM stdin;
\.


--
-- Data for Name: service_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_orders (id, order_number, vehicle_id, mechanic_id, description, parts_json, labor_cost, parts_cost, total_cost, status, mileage_in, mileage_out, created_at, started_at, completed_at, notes, pdf_path) FROM stdin;
\.


--
-- Data for Name: staff_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_reports (id, user_id, stars, date) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, contact_person, phone, email, address, inn, delivery_days, min_order_amount, rating, is_active, created_at, notes) FROM stdin;
\.


--
-- Data for Name: technical_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technical_checks (id, vehicle_id, mechanic_id, check_type, check_time, is_passed) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, tenant_id, park_name, yandex_tx_id, yandex_driver_id, category_type, created_at, category, contractor, description, plate_info, amount, tx_type, date, responsibility, is_debt_repayment) FROM stdin;
1	s-global	LOGISTICS	\N	\N	REVENUE	2026-03-14 03:22:58.732805	VkusVill	Азат (5т)	Рейс #1 — Даркстор (ВкусВилл)	А001АА777	6599	income	2026-03-10 00:00:00	park	f
2	s-global	LOGISTICS	\N	\N	REVENUE	2026-03-14 03:22:58.73281	VkusVill	Азат (5т)	Рейс #2 — Магазин (ВкусВилл)	А001АА777	5883	income	2026-03-10 00:00:00	park	f
3	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732811	Salary	Азат (5т)	ЗП водителя — 2 рейса	А001АА777	-4000	expense	2026-03-10 00:00:00	park	f
4	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732812	Fuel	Азат (5т)	Топливо — 2 рейса	А001АА777	-5000	expense	2026-03-10 00:00:00	park	f
5	s-global	LOGISTICS	\N	\N	REVENUE	2026-03-14 03:22:58.732812	VkusVill	Газель-1 (партнёр)	Рейс — Шмель (ВкусВилл)	В002ВВ750	3882	income	2026-03-10 00:00:00	park	f
6	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732812	Salary	Газель-1 (партнёр)	ЗП водителя газели	В002ВВ750	-1500	expense	2026-03-10 00:00:00	park	f
7	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732813	Fuel	Газель-1 (партнёр)	Топливо газели	В002ВВ750	-1800	expense	2026-03-10 00:00:00	park	f
8	s-global	LOGISTICS	\N	\N	REVENUE	2026-03-14 03:22:58.732813	VkusVill	Газель-2 (партнёр)	Рейс — Шмель (ВкусВилл)	С003СС750	3882	income	2026-03-10 00:00:00	park	f
9	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732814	Salary	Газель-2 (партнёр)	ЗП водителя газели	С003СС750	-1500	expense	2026-03-10 00:00:00	park	f
10	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732814	Fuel	Газель-2 (партнёр)	Топливо газели	С003СС750	-1800	expense	2026-03-10 00:00:00	park	f
11	s-global	LOGISTICS	\N	\N	REVENUE	2026-03-14 03:22:58.732814	VkusVill	Газель-3 (партнёр)	Рейс — Даркстор (ВкусВилл)	Е004ЕЕ750	6599	income	2026-03-10 00:00:00	park	f
12	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732815	Salary	Газель-3 (партнёр)	ЗП водителя газели	Е004ЕЕ750	-1500	expense	2026-03-10 00:00:00	park	f
13	s-global	LOGISTICS	\N	\N	EXPENSES	2026-03-14 03:22:58.732815	Fuel	Газель-3 (партнёр)	Топливо газели	Е004ЕЕ750	-1800	expense	2026-03-10 00:00:00	park	f
\.


--
-- Data for Name: trip_sheets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trip_sheets (id, trip_number, driver_id, vehicle_id, start_time, actual_end_time, start_location, start_odometer, medical_check_id, technical_check_id, briefing_id, kis_art_required, kis_art_sent, kis_art_response, status, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, username, hashed_password, full_name, photo_url, telegram_id, phone, role, rating, park_name, can_see_treasury, can_see_fleet, can_see_analytics, can_see_logistics, can_see_hr, can_edit_users, language, theme, is_active, created_at, last_active_at, is_archived, is_core_active, base_salary, kpi_bonus_ratio, m4_fines_count, realtime_status, work_status, yandex_driver_id, yandex_contractor_id, driver_class, daily_rent, base_cost, driver_balance, current_vehicle_id, yandex_work_status, yandex_balance_updated_at, yandex_rating, yandex_phones, yandex_names, yandex_current_car, yandex_last_sync_at, license_number, license_issue_date, license_expiry_date, license_country, driving_experience_from, birth_date, hire_date, first_order_date, balance_limit, driver_documents) FROM stdin;
5	s-global	logist	$2b$12$QYPv8bWdRPi94aS0l7sINOkRAjFwW2cnfqDNSYHd/AKuai/Norqi2	Логист С-ГЛОБАЛ	\N	\N	\N	manager	5	EXPRESS	t	t	t	t	t	f	ru	luxury	t	2026-03-14 02:19:10.466012	\N	t	f	130000	0	0	offline	not_working	\N	\N	economy	2000	1600	0	\N	\N	\N	\N	[]	{}	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	5	{}
1	s-global	master	$2b$12$1jOEr0qQKgOx5GgTHDj1j.HBDEdWNz3BOO3WRguEIBzxcUJ3zIp6y	Master Spartak	\N	\N	\N	master	5	PRO	t	t	t	t	t	t	ru	luxury	t	2026-03-13 23:39:43.291455	\N	f	f	130000	0	0	offline	not_working	\N	\N	economy	2000	1600	0	\N	\N	\N	\N	[]	{}	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	5	{}
2	s-global	afunts	$2b$12$TCZfXX0fnBbcHVA.uhWhFeLfW9p8u9Dk2O7inp/qMzFcc35/7BzYi	Афунц Алик	\N	\N	\N	director	5	PRO	t	t	t	t	t	f	ru	luxury	t	2026-03-14 02:19:09.825913	\N	f	f	130000	0	0	offline	not_working	\N	\N	economy	2000	1600	0	\N	\N	\N	\N	[]	{}	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	5	{}
3	s-global	volkov	$2b$12$BGiF4sv8CC88o9QzSJcCrexvCe3A9HWGHG2iB6kU3.BWEQ8Gvpsfe	Волков Михаил	\N	\N	\N	director	5	PRO	t	t	t	t	t	f	ru	luxury	t	2026-03-14 02:19:10.052198	\N	f	f	130000	0	0	offline	not_working	\N	\N	economy	2000	1600	0	\N	\N	\N	\N	[]	{}	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	5	{}
4	s-global	gevorgyan	$2b$12$r0IozbuClAmXecvrLoEOeuqV11xijprAvoDbrPijPLFlUMbgGGeqm	Геворгян Левон	\N	\N	\N	director	5	PRO	t	t	t	t	t	f	ru	luxury	t	2026-03-14 02:19:10.261403	\N	f	f	130000	0	0	offline	not_working	\N	\N	economy	2000	1600	0	\N	\N	\N	\N	[]	{}	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	5	{}
\.


--
-- Data for Name: vehicle_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_profiles (id, vehicle_id, osago_number, osago_expiry, kasko_number, kasko_expiry, license_expiry, diagnostic_card_expiry, last_to_date, next_to_date, to_interval_km, trip_sheets_count, acceptance_acts_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_repair_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_repair_history (id, vehicle_id, parts_json, description, repair_cost, status, created_at) FROM stdin;
\.


--
-- Data for Name: vehicle_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_status_history (id, vehicle_id, old_status, new_status, changed_by, changed_at, reason) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicles (id, tenant_id, brand, model, license_plate, vin, color, year, sts_number, callsign, owner_id, ownership_type, commission_rate, fixed_fee, park_name, is_park_car, tariff_id, is_active, is_free, status, current_driver_id, current_mileage, next_service_km, yandex_car_id, yandex_driver_id, last_update, created_at, is_active_dominion, last_transaction_at, yandex_status, yandex_rental, yandex_last_sync_at, yandex_park_id) FROM stdin;
\.


--
-- Data for Name: warehouse_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouse_items (id, name, sku, category, quantity, min_threshold, price_unit, updated_at) FROM stdin;
\.


--
-- Data for Name: warehouse_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouse_logs (id, item_id, change, vehicle_id, master_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: yandex_sync_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.yandex_sync_log (id, sync_type, park_id, records_processed, records_created, records_updated, errors_count, error_details, started_at, finished_at, duration_seconds) FROM stdin;
\.


--
-- Name: briefings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.briefings_id_seq', 1, false);


--
-- Name: call_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.call_logs_id_seq', 1, false);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_messages_id_seq', 2, true);


--
-- Name: contract_term_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_term_history_id_seq', 1, false);


--
-- Name: contract_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_terms_id_seq', 1, false);


--
-- Name: driver_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.driver_profiles_id_seq', 1, false);


--
-- Name: driver_tension_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.driver_tension_history_id_seq', 1, false);


--
-- Name: financial_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.financial_log_id_seq', 1, true);


--
-- Name: fine_installments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fine_installments_id_seq', 1, false);


--
-- Name: logistics_drivers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logistics_drivers_id_seq', 1, false);


--
-- Name: logistics_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logistics_routes_id_seq', 17, true);


--
-- Name: medical_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.medical_checks_id_seq', 1, false);


--
-- Name: oracle_archive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oracle_archive_id_seq', 1, false);


--
-- Name: partner_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.partner_ledger_id_seq', 1, false);


--
-- Name: partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.partners_id_seq', 1, false);


--
-- Name: referrals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.referrals_id_seq', 1, false);


--
-- Name: rental_tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rental_tariffs_id_seq', 1, false);


--
-- Name: service_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_orders_id_seq', 1, false);


--
-- Name: staff_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_reports_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, false);


--
-- Name: technical_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.technical_checks_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 13, true);


--
-- Name: trip_sheets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trip_sheets_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: vehicle_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_profiles_id_seq', 1, false);


--
-- Name: vehicle_repair_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_repair_history_id_seq', 1, false);


--
-- Name: vehicle_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_status_history_id_seq', 1, false);


--
-- Name: vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicles_id_seq', 1, false);


--
-- Name: warehouse_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouse_items_id_seq', 1, false);


--
-- Name: warehouse_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouse_logs_id_seq', 1, false);


--
-- Name: yandex_sync_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.yandex_sync_log_id_seq', 1, false);


--
-- Name: briefings briefings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefings
    ADD CONSTRAINT briefings_pkey PRIMARY KEY (id);


--
-- Name: call_logs call_logs_asterisk_unique_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT call_logs_asterisk_unique_id_key UNIQUE (asterisk_unique_id);


--
-- Name: call_logs call_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT call_logs_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: contract_term_history contract_term_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_term_history
    ADD CONSTRAINT contract_term_history_pkey PRIMARY KEY (id);


--
-- Name: contract_terms contract_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_terms
    ADD CONSTRAINT contract_terms_pkey PRIMARY KEY (id);


--
-- Name: driver_profiles driver_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.driver_profiles
    ADD CONSTRAINT driver_profiles_pkey PRIMARY KEY (id);


--
-- Name: driver_profiles driver_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.driver_profiles
    ADD CONSTRAINT driver_profiles_user_id_key UNIQUE (user_id);


--
-- Name: driver_tension_history driver_tension_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.driver_tension_history
    ADD CONSTRAINT driver_tension_history_pkey PRIMARY KEY (id);


--
-- Name: financial_log financial_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_log
    ADD CONSTRAINT financial_log_pkey PRIMARY KEY (id);


--
-- Name: fine_installments fine_installments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fine_installments
    ADD CONSTRAINT fine_installments_pkey PRIMARY KEY (id);


--
-- Name: logistics_drivers logistics_drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_drivers
    ADD CONSTRAINT logistics_drivers_pkey PRIMARY KEY (id);


--
-- Name: logistics_routes logistics_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_routes
    ADD CONSTRAINT logistics_routes_pkey PRIMARY KEY (id);


--
-- Name: medical_checks medical_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_checks
    ADD CONSTRAINT medical_checks_pkey PRIMARY KEY (id);


--
-- Name: oracle_archive oracle_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oracle_archive
    ADD CONSTRAINT oracle_archive_pkey PRIMARY KEY (id);


--
-- Name: partner_ledger partner_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_ledger
    ADD CONSTRAINT partner_ledger_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: rental_tariffs rental_tariffs_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rental_tariffs
    ADD CONSTRAINT rental_tariffs_name_key UNIQUE (name);


--
-- Name: rental_tariffs rental_tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rental_tariffs
    ADD CONSTRAINT rental_tariffs_pkey PRIMARY KEY (id);


--
-- Name: service_orders service_orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_order_number_key UNIQUE (order_number);


--
-- Name: service_orders service_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_pkey PRIMARY KEY (id);


--
-- Name: staff_reports staff_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_reports
    ADD CONSTRAINT staff_reports_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: technical_checks technical_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_checks
    ADD CONSTRAINT technical_checks_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: trip_sheets trip_sheets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_sheets
    ADD CONSTRAINT trip_sheets_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_yandex_driver_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_yandex_driver_id_key UNIQUE (yandex_driver_id);


--
-- Name: vehicle_profiles vehicle_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_profiles
    ADD CONSTRAINT vehicle_profiles_pkey PRIMARY KEY (id);


--
-- Name: vehicle_profiles vehicle_profiles_vehicle_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_profiles
    ADD CONSTRAINT vehicle_profiles_vehicle_id_key UNIQUE (vehicle_id);


--
-- Name: vehicle_repair_history vehicle_repair_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_repair_history
    ADD CONSTRAINT vehicle_repair_history_pkey PRIMARY KEY (id);


--
-- Name: vehicle_status_history vehicle_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_status_history
    ADD CONSTRAINT vehicle_status_history_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: warehouse_items warehouse_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_pkey PRIMARY KEY (id);


--
-- Name: warehouse_logs warehouse_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_logs
    ADD CONSTRAINT warehouse_logs_pkey PRIMARY KEY (id);


--
-- Name: yandex_sync_log yandex_sync_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yandex_sync_log
    ADD CONSTRAINT yandex_sync_log_pkey PRIMARY KEY (id);


--
-- Name: ix_briefings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_briefings_id ON public.briefings USING btree (id);


--
-- Name: ix_call_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_call_logs_id ON public.call_logs USING btree (id);


--
-- Name: ix_call_logs_tenant_caller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_call_logs_tenant_caller ON public.call_logs USING btree (tenant_id, caller_phone);


--
-- Name: ix_call_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_call_logs_tenant_id ON public.call_logs USING btree (tenant_id);


--
-- Name: ix_call_logs_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_call_logs_timestamp ON public.call_logs USING btree ("timestamp");


--
-- Name: ix_chat_messages_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_created_at ON public.chat_messages USING btree (created_at);


--
-- Name: ix_chat_messages_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_id ON public.chat_messages USING btree (id);


--
-- Name: ix_chat_messages_is_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_is_read ON public.chat_messages USING btree (is_read);


--
-- Name: ix_contract_term_history_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_term_history_changed_at ON public.contract_term_history USING btree (changed_at);


--
-- Name: ix_contract_term_history_contract_term_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_term_history_contract_term_id ON public.contract_term_history USING btree (contract_term_id);


--
-- Name: ix_contract_term_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_term_history_id ON public.contract_term_history USING btree (id);


--
-- Name: ix_contract_term_history_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_term_history_vehicle_id ON public.contract_term_history USING btree (vehicle_id);


--
-- Name: ix_contract_terms_driver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_terms_driver_id ON public.contract_terms USING btree (driver_id);


--
-- Name: ix_contract_terms_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_terms_id ON public.contract_terms USING btree (id);


--
-- Name: ix_contract_terms_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_terms_is_default ON public.contract_terms USING btree (is_default);


--
-- Name: ix_contract_terms_park_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_terms_park_name ON public.contract_terms USING btree (park_name);


--
-- Name: ix_contract_terms_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contract_terms_vehicle_id ON public.contract_terms USING btree (vehicle_id);


--
-- Name: ix_driver_profiles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_driver_profiles_id ON public.driver_profiles USING btree (id);


--
-- Name: ix_driver_profiles_license_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_driver_profiles_license_expiry ON public.driver_profiles USING btree (license_expiry);


--
-- Name: ix_driver_profiles_license_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_driver_profiles_license_number ON public.driver_profiles USING btree (license_number);


--
-- Name: ix_driver_profiles_medical_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_driver_profiles_medical_expiry ON public.driver_profiles USING btree (medical_expiry);


--
-- Name: ix_driver_profiles_yandex_driver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_driver_profiles_yandex_driver_id ON public.driver_profiles USING btree (yandex_driver_id);


--
-- Name: ix_driver_tension_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_driver_tension_history_id ON public.driver_tension_history USING btree (id);


--
-- Name: ix_financial_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_financial_log_created_at ON public.financial_log USING btree (created_at);


--
-- Name: ix_financial_log_driver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_financial_log_driver_id ON public.financial_log USING btree (driver_id);


--
-- Name: ix_financial_log_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_financial_log_id ON public.financial_log USING btree (id);


--
-- Name: ix_financial_log_park_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_financial_log_park_name ON public.financial_log USING btree (park_name);


--
-- Name: ix_financial_log_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_financial_log_vehicle_id ON public.financial_log USING btree (vehicle_id);


--
-- Name: ix_fine_installments_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fine_installments_id ON public.fine_installments USING btree (id);


--
-- Name: ix_logistics_drivers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_drivers_id ON public.logistics_drivers USING btree (id);


--
-- Name: ix_logistics_drivers_park_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_drivers_park_name ON public.logistics_drivers USING btree (park_name);


--
-- Name: ix_logistics_drivers_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_drivers_tenant_id ON public.logistics_drivers USING btree (tenant_id);


--
-- Name: ix_logistics_routes_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_routes_date ON public.logistics_routes USING btree (date);


--
-- Name: ix_logistics_routes_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_routes_id ON public.logistics_routes USING btree (id);


--
-- Name: ix_logistics_routes_park_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_routes_park_name ON public.logistics_routes USING btree (park_name);


--
-- Name: ix_logistics_routes_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_routes_tenant_id ON public.logistics_routes USING btree (tenant_id);


--
-- Name: ix_medical_checks_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medical_checks_id ON public.medical_checks USING btree (id);


--
-- Name: ix_oracle_archive_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_oracle_archive_created_at ON public.oracle_archive USING btree (created_at);


--
-- Name: ix_oracle_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_oracle_archive_id ON public.oracle_archive USING btree (id);


--
-- Name: ix_partner_ledger_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_ledger_date ON public.partner_ledger USING btree (date);


--
-- Name: ix_partner_ledger_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_ledger_id ON public.partner_ledger USING btree (id);


--
-- Name: ix_partner_ledger_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_ledger_partner_id ON public.partner_ledger USING btree (partner_id);


--
-- Name: ix_partner_ledger_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_ledger_vehicle_id ON public.partner_ledger USING btree (vehicle_id);


--
-- Name: ix_partners_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partners_id ON public.partners USING btree (id);


--
-- Name: ix_partners_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_partners_phone ON public.partners USING btree (phone);


--
-- Name: ix_referrals_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_referrals_id ON public.referrals USING btree (id);


--
-- Name: ix_rental_tariffs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rental_tariffs_id ON public.rental_tariffs USING btree (id);


--
-- Name: ix_service_orders_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_orders_id ON public.service_orders USING btree (id);


--
-- Name: ix_staff_reports_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_staff_reports_id ON public.staff_reports USING btree (id);


--
-- Name: ix_suppliers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_suppliers_id ON public.suppliers USING btree (id);


--
-- Name: ix_technical_checks_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_technical_checks_id ON public.technical_checks USING btree (id);


--
-- Name: ix_transactions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_transactions_id ON public.transactions USING btree (id);


--
-- Name: ix_transactions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_transactions_tenant_id ON public.transactions USING btree (tenant_id);


--
-- Name: ix_transactions_yandex_driver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_transactions_yandex_driver_id ON public.transactions USING btree (yandex_driver_id);


--
-- Name: ix_transactions_yandex_tx_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_transactions_yandex_tx_id ON public.transactions USING btree (yandex_tx_id);


--
-- Name: ix_trip_sheets_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trip_sheets_id ON public.trip_sheets USING btree (id);


--
-- Name: ix_trip_sheets_trip_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_trip_sheets_trip_number ON public.trip_sheets USING btree (trip_number);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_users_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_users_yandex_contractor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_yandex_contractor_id ON public.users USING btree (yandex_contractor_id);


--
-- Name: ix_vehicle_profiles_diagnostic_card_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_profiles_diagnostic_card_expiry ON public.vehicle_profiles USING btree (diagnostic_card_expiry);


--
-- Name: ix_vehicle_profiles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_profiles_id ON public.vehicle_profiles USING btree (id);


--
-- Name: ix_vehicle_profiles_kasko_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_profiles_kasko_expiry ON public.vehicle_profiles USING btree (kasko_expiry);


--
-- Name: ix_vehicle_profiles_license_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_profiles_license_expiry ON public.vehicle_profiles USING btree (license_expiry);


--
-- Name: ix_vehicle_profiles_next_to_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_profiles_next_to_date ON public.vehicle_profiles USING btree (next_to_date);


--
-- Name: ix_vehicle_profiles_osago_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_profiles_osago_expiry ON public.vehicle_profiles USING btree (osago_expiry);


--
-- Name: ix_vehicle_repair_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_repair_history_id ON public.vehicle_repair_history USING btree (id);


--
-- Name: ix_vehicle_status_history_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_status_history_changed_at ON public.vehicle_status_history USING btree (changed_at);


--
-- Name: ix_vehicle_status_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_status_history_id ON public.vehicle_status_history USING btree (id);


--
-- Name: ix_vehicle_status_history_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_status_history_vehicle_id ON public.vehicle_status_history USING btree (vehicle_id);


--
-- Name: ix_vehicles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicles_id ON public.vehicles USING btree (id);


--
-- Name: ix_vehicles_is_active_dominion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicles_is_active_dominion ON public.vehicles USING btree (is_active_dominion);


--
-- Name: ix_vehicles_license_plate; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_vehicles_license_plate ON public.vehicles USING btree (license_plate);


--
-- Name: ix_vehicles_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicles_tenant_id ON public.vehicles USING btree (tenant_id);


--
-- Name: ix_vehicles_yandex_car_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicles_yandex_car_id ON public.vehicles USING btree (yandex_car_id);


--
-- Name: ix_vehicles_yandex_driver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicles_yandex_driver_id ON public.vehicles USING btree (yandex_driver_id);


--
-- Name: ix_warehouse_items_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_warehouse_items_id ON public.warehouse_items USING btree (id);


--
-- Name: ix_warehouse_items_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_warehouse_items_sku ON public.warehouse_items USING btree (sku);


--
-- Name: ix_warehouse_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_warehouse_logs_id ON public.warehouse_logs USING btree (id);


--
-- Name: ix_yandex_sync_log_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_yandex_sync_log_id ON public.yandex_sync_log USING btree (id);


--
-- Name: ix_yandex_sync_log_park_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_yandex_sync_log_park_id ON public.yandex_sync_log USING btree (park_id);


--
-- Name: ix_yandex_sync_log_started_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_yandex_sync_log_started_at ON public.yandex_sync_log USING btree (started_at);


--
-- Name: uq_tx_park_yandex_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tx_park_yandex_id ON public.transactions USING btree (park_name, yandex_tx_id) WHERE (yandex_tx_id IS NOT NULL);


--
-- Name: briefings briefings_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefings
    ADD CONSTRAINT briefings_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.users(id);


--
-- Name: briefings briefings_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefings
    ADD CONSTRAINT briefings_instructor_id_fkey FOREIGN KEY (instructor_id) REFERENCES public.users(id);


--
-- Name: call_logs call_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT call_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.chat_messages(id);


--
-- Name: chat_messages chat_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: contract_term_history contract_term_history_changed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_term_history
    ADD CONSTRAINT contract_term_history_changed_by_user_id_fkey FOREIGN KEY (changed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: contract_term_history contract_term_history_contract_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_term_history
    ADD CONSTRAINT contract_term_history_contract_term_id_fkey FOREIGN KEY (contract_term_id) REFERENCES public.contract_terms(id) ON DELETE CASCADE;


--
-- Name: contract_term_history contract_term_history_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_term_history
    ADD CONSTRAINT contract_term_history_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: contract_terms contract_terms_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_terms
    ADD CONSTRAINT contract_terms_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: contract_terms contract_terms_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_terms
    ADD CONSTRAINT contract_terms_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: driver_profiles driver_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.driver_profiles
    ADD CONSTRAINT driver_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: driver_tension_history driver_tension_history_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.driver_tension_history
    ADD CONSTRAINT driver_tension_history_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: financial_log financial_log_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_log
    ADD CONSTRAINT financial_log_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: financial_log financial_log_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_log
    ADD CONSTRAINT financial_log_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE SET NULL;


--
-- Name: fine_installments fine_installments_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fine_installments
    ADD CONSTRAINT fine_installments_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: medical_checks medical_checks_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_checks
    ADD CONSTRAINT medical_checks_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.users(id);


--
-- Name: medical_checks medical_checks_medical_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_checks
    ADD CONSTRAINT medical_checks_medical_staff_id_fkey FOREIGN KEY (medical_staff_id) REFERENCES public.users(id);


--
-- Name: partner_ledger partner_ledger_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_ledger
    ADD CONSTRAINT partner_ledger_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id);


--
-- Name: partner_ledger partner_ledger_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_ledger
    ADD CONSTRAINT partner_ledger_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: referrals referrals_referral_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referral_id_fkey FOREIGN KEY (referral_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: service_orders service_orders_mechanic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_mechanic_id_fkey FOREIGN KEY (mechanic_id) REFERENCES public.users(id);


--
-- Name: service_orders service_orders_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: staff_reports staff_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_reports
    ADD CONSTRAINT staff_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: technical_checks technical_checks_mechanic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_checks
    ADD CONSTRAINT technical_checks_mechanic_id_fkey FOREIGN KEY (mechanic_id) REFERENCES public.users(id);


--
-- Name: technical_checks technical_checks_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_checks
    ADD CONSTRAINT technical_checks_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: trip_sheets trip_sheets_briefing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_sheets
    ADD CONSTRAINT trip_sheets_briefing_id_fkey FOREIGN KEY (briefing_id) REFERENCES public.briefings(id);


--
-- Name: trip_sheets trip_sheets_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_sheets
    ADD CONSTRAINT trip_sheets_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.users(id);


--
-- Name: trip_sheets trip_sheets_medical_check_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_sheets
    ADD CONSTRAINT trip_sheets_medical_check_id_fkey FOREIGN KEY (medical_check_id) REFERENCES public.medical_checks(id);


--
-- Name: trip_sheets trip_sheets_technical_check_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_sheets
    ADD CONSTRAINT trip_sheets_technical_check_id_fkey FOREIGN KEY (technical_check_id) REFERENCES public.technical_checks(id);


--
-- Name: trip_sheets trip_sheets_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trip_sheets
    ADD CONSTRAINT trip_sheets_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: vehicle_profiles vehicle_profiles_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_profiles
    ADD CONSTRAINT vehicle_profiles_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: vehicle_repair_history vehicle_repair_history_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_repair_history
    ADD CONSTRAINT vehicle_repair_history_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: vehicle_status_history vehicle_status_history_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_status_history
    ADD CONSTRAINT vehicle_status_history_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: warehouse_logs warehouse_logs_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_logs
    ADD CONSTRAINT warehouse_logs_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.warehouse_items(id);


--
-- Name: warehouse_logs warehouse_logs_master_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_logs
    ADD CONSTRAINT warehouse_logs_master_id_fkey FOREIGN KEY (master_id) REFERENCES public.users(id);


--
-- Name: warehouse_logs warehouse_logs_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_logs
    ADD CONSTRAINT warehouse_logs_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Pa2siZTsFGzkt7uDYgFgTqgxtlcVuvkGbhM1EShQUYQrnAKjwqCSCuSJjsb80gv

